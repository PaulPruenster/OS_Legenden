int square_my_integer(int x) {
  return (x * x); // + 1; was the bug
}
